 /*
 #
 # Documentacion openACS - Creacion e integracion de un paquete openACS en dotLRN
 # web site: http://www.dotlrn-experiments.blogspot.com
 # 
 # This file is part of Documentacion openACS.
 # Written by Francisco Garcia Jimena <franciscogarciaj@gmail.com> 
 #            Juan Jesus Gutierrez Ruiz <jjgr73@hotmail.com>
 #	      Antonio Luis Batista Archilla <albatista@gmail.com>
 #	      Juan Carneros Montoya <juancarneros@gmail.com>
 #
 # Documentacion openACS is free software; you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation; either version 2 of the License, or
 # (at your option) any later version.
 #
 # Documentacion openACS is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 #
 # You should have received a copy of the GNU General Public License
 # along with this program; if not, write to the Free Software
 # Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 #
 */

select content_type__create_type(
    'prueba',                    -- content_type
    'content_revision',            -- supertype
    'prueba',                    -- pretty_name,
    'prueba',                   -- pretty_plural
    'prueba',                   -- table_name
    'prueba_id',                     -- id_column
    null                           -- name_method
);

select content_type__create_attribute (
   'prueba',               -- content_type
   'nombre',                  -- attribute_name
   'string',                   -- datatype
   'nombre',                  -- pretty_name
   null,                -- pretty_plural
   null,                     -- sort_order
   null,                     -- default_value
   'text'                    -- column_spec
 );


select content_type__create_attribute (
   'prueba',               -- content_type
   'apellidos',                  -- attribute_name
   'string',                   -- datatype
   'apellidos',                  -- pretty_name
   null,                -- pretty_plural
   null,                     -- sort_order
   null,                     -- default_value
   'text'                    -- column_spec
 );

select content_type__create_attribute (
   'prueba',               -- content_type
   'fecha_nacimiento',                  -- attribute_name
   'string',                   -- datatype
   'fecha de nacimiento',                  -- pretty_name
   null,                -- pretty_plural
   null,                     -- sort_order
   null,                     -- default_value
   'text'                    -- column_spec
 );

select content_type__create_attribute (
   'prueba',               -- content_type
   'direccion',                  -- attribute_name
   'string',                   -- datatype
   'direccion',                  -- pretty_name
   null,                -- pretty_plural
   null,                     -- sort_order
   null,                     -- default_value
   'text'                    -- column_spec
 );


select content_type__create_attribute (
   'prueba',               -- content_type
   'telefono',                  -- attribute_name
   'string',                   -- datatype
   'telefono',                  -- pretty_name
   null,                -- pretty_plural
   null,                     -- sort_order
   null,                     -- default_value
   'text'                    -- column_spec
 );

select content_type__create_attribute (
   'prueba',               -- content_type
   'email',                  -- attribute_name
   'string',                   -- datatype
   'correo electronico',                  -- pretty_name
   null,                -- pretty_plural
   null,                     -- sort_order
   null,                     -- default_value
   'text'                    -- column_spec
 );

select content_type__create_attribute (
   'prueba',               -- content_type
   'comentarios',                  -- attribute_name
   'string',                   -- datatype
   'comentarios',                  -- pretty_name
   null,                -- pretty_plural
   null,                     -- sort_order
   null,                     -- default_value
   'text'                    -- column_spec
 );



-- necessary to work around limitation of content repository:
select content_folder__register_content_type(-100,'prueba','t');
