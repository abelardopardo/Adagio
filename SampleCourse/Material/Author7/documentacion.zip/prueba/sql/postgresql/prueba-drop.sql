/*
 #
 # Documentacion openACS - Creacion e integracion de un paquete openACS en dotLRN
 # web site: http://www.dotlrn-experiments.blogspot.com
 # 
 # This file is part of Documentacion openACS.
 # Written by Francisco Garcia Jimena <franciscogarciaj@gmail.com> 
 #            Juan Jesus Gutierrez Ruiz <jjgr73@hotmail.com>
 #	      Antonio Luis Batista Archilla <albatista@gmail.com>
 #	      Juan Carneros Montoya <juancarneros@gmail.com>
 #
 # Documentacion openACS is free software; you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation; either version 2 of the License, or
 # (at your option) any later version.
 #
 # Documentacion openACS is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 #
 # You should have received a copy of the GNU General Public License
 # along with this program; if not, write to the Free Software
 # Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 #
*/

select content_folder__unregister_content_type(-100,'prueba','t');


select content_type__drop_attribute(
        'prueba',
        'nombre',
        't'
);

select content_type__drop_attribute(
        'prueba',
        'apellidos',
        't'
);

select content_type__drop_attribute(
        'prueba',
        'fecha_nacimiento',
        't'
);

select content_type__drop_attribute(
        'prueba',
        'direccion',
        't'
);
select content_type__drop_attribute(
        'prueba',
        'telefono',
        't'
);

select content_type__drop_attribute(
        'prueba',
        'comentarios',
        't'
);

select content_type__drop_type(
           'prueba',
           't',
           't'
    );

